Plaats hier je codes gerelateerd aan de Arduino kant van de atm
