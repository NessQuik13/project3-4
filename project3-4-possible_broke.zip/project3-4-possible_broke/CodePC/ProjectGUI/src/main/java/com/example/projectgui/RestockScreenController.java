package com.example.projectgui;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class RestockScreenController {

    @FXML
    private Label T1;

    public void initialize() {
        Singleton language = Singleton.getInstance();
        if (!language.getIsEnglish()) {
            T1.setText("De ATM wordt momenteel hervuld");
        }
    }
}
